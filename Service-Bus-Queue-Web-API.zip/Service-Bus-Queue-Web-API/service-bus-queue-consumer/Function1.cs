using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;

namespace service_bus_queue_consumer
{
    public class Function1
    {
        [FunctionName("Function1")]
        public void Run([ServiceBusTrigger("add-weather-data", Connection = "WeatherDataConnectionString")]string myQueueItem, ILogger log)
        {
            // logic
            // save db
            // email
            // send data to another api

            log.LogInformation($"C# ServiceBus queue trigger function processed message: {myQueueItem}");
        }
    }
}
