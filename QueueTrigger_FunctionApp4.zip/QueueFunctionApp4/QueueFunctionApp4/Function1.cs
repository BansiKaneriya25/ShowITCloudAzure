using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;

namespace QueueFunctionApp4
{
    public class Function1
    {
        [FunctionName("QueueFunctionProcess")]
        public void Run([QueueTrigger("myqueueshowit-items", Connection = "QueueConnectionName")]string myQueueItem, ILogger log)
        {
            if (myQueueItem.Contains("execption"))
            {
                throw new Exception("Not Found Queue message");
            }
            // we can write logic
            log.LogInformation($"C# Queue trigger function processed: {myQueueItem}");
        }
    }
}
